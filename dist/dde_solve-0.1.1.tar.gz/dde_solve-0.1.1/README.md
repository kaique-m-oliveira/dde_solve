Numerical solver for delay differential equations (DDEs) and neutral delay differential equations (NDDEs)
